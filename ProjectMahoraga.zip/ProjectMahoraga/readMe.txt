genre bhi dal gai or anime page bhi pyara sa ho gya
session token working
working watchlist
signup page
discussion page working
profile added
reviews done
ratings front end added
genre working
anime Search working
genre Search working
all buttons are functioning
showing ratings 
inserting rating
watched and favourite button added
anime view
users view
users del
anime del
footers
Admin pages
correct genders bhar ma jayan genders we use email
